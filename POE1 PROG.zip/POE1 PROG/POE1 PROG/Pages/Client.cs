﻿using System;
using System.Collections.Generic;

namespace ContractMonthlyClaimSystem
{
    // Represents a Client
    public class Client
    {
        public int ClientId { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Address { get; set; }
        public string TaxNumber { get; set; }

        // Relationships
        public List<Contract> Contracts { get; set; } = new List<Contract>();
    }

    // Represents a Contract linked to a Client
    public class Contract
    {
        public int ContractId { get; set; }
        public string ContractType { get; set; }
        public DateTime StartDate { get; set; }
        public decimal ContractValue { get; set; }

        // Relationships
        public Client Client { get; set; }
        public List<Claim> Claims { get; set; } = new List<Claim>();
    }

    // Represents a Monthly Claim for a Contract
    public class Claim
    {
        public int ClaimId { get; set; }
        public DateTime ClaimDate { get; set; }
        public decimal ClaimAmount { get; set; }
        public string Status { get; set; } // e.g. "Pending", "Approved", "Rejected"

        // Relationship
        public Contract Contract { get; set; }
    }

    // Test Program
    class Program
    {
        static void Main(string[] args)
        {
            // Create client
            Client client = new Client
            {
                ClientId = 1,
                Name = "Inathi",
                Surname = "Doloni",
                Address = "123 Main Street",
                TaxNumber = "TX12345"
            };

            // Create contract
            Contract contract = new Contract
            {
                ContractId = 101,
                ContractType = "Maintenance",
                StartDate = DateTime.Now.AddMonths(-3),
                ContractValue = 5000,
                Client = client
            };

            // Link contract to client
            client.Contracts.Add(contract);

            // Create claim
            Claim claim = new Claim
            {
                ClaimId = 1001,
                ClaimDate = DateTime.Now,
                ClaimAmount = 1200,
                Status = "Pending",
                Contract = contract
            };

            // Link claim to contract
            contract.Claims.Add(claim);

            // Output to console
            Console.WriteLine($"Client: {client.Name} {client.Surname}");
            Console.WriteLine($"Contract: {contract.ContractType} - Value: {contract.ContractValue:C}");
            Console.WriteLine($"Claim: {claim.ClaimAmount:C} on {claim.ClaimDate.ToShortDateString()} [{claim.Status}]");

            Console.ReadLine();
        }
    }
}
