﻿using System;

namespace CMCS.Models
{
    public class ProjectTask
    {
        public int TaskId { get; set; }
        public string Name { get; set; } = "";
        public string Details { get; set; } = "";
        public string Dependencies { get; set; } = "";
        public int DurationDays { get; set; }
        public int StartDay { get; set; }
        public int EndDay => StartDay + DurationDays - 1;

        public override string ToString()
        {
            return $"{TaskId}. {Name} (Day {StartDay}–{EndDay})\n" +
                   $"   Details: {Details}\n" +
                   $"   Dependencies: {Dependencies}\n" +
                   $"   Duration: {DurationDays} days\n";
        }
    }
}

 

