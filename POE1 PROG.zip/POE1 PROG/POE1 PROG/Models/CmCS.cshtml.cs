using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace POE1_PROG.Models
{
    public class CmCSModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
